#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
================================================================================
INSTITUTO FEDERAL DO CEARÁ -- CAMPUS TAUÁ
CURSO SUPERIOR DE TECNOLOGIA EM ANÁLISE E DESENVOLVIMENTO DE SISTEMAS (ADS)
COMPONENTE CURRICULAR: BANCO DE DADOS NÃO-RELACIONAIS (ADS16)
AVALIAÇÃO PRÁTICA 1 (AVP1) -- LABORATÓRIO N1 (17/11/2026)
Docente: Prof. Me. Reginaldo Pereira Fernandes
================================================================================

Nome do Discente / Dupla: ____________________________________________________
Matrícula(s): _______________________________________________________________

INSTRUÇÕES OBRIGATÓRIAS:
1. Certifique-se de que os containers do Redis e MongoDB estão em execução:
   $ docker compose up -d
2. Execute o script de povoamento prévio antes de iniciar:
   $ python povoar_ambiente_avp1.py
3. Complete o código de cada um dos 5 desafios nos blocos indicados por TODO.
4. Execute este script para rodar a suíte oficial de testes automatizados:
   $ python avp1_desafios_aluno.py
5. Cada desafio vale 2,0 pontos (Pontuação máxima: 10,0 pontos).
6. Prazo final de submissão: Domingo, 22/11/2026, até às 23h59 via Google Classroom da disciplina.
"""

import json
from datetime import datetime, timezone
import redis
from pymongo import MongoClient

def get_conexoes():
    """Retorna conexões ativas com as instâncias locais do Redis e MongoDB."""
    r = redis.Redis(host="localhost", port=6379, decode_responses=True)
    m = MongoClient("mongodb://localhost:27017")
    db = m["ecommerce_shopgrids"]
    return r, db

# ==============================================================================
# DESAFIO 1 (Valor: 2,0 Pontos) -- Padrão Cache-Aside com TTL no Redis
# ==============================================================================
def buscar_produto_com_cache(r: redis.Redis, db, sku: str, ttl_segundos: int = 90) -> dict:
    """
    Especificação do Requisito:
    1. Verifica se a chave 'produto:{sku}' existe no Redis.
    2. Se existir (Cache Hit): desserializa a string JSON e adiciona o campo
       '_origem': 'REDIS_CACHE', retornando o dicionário resultante.
    3. Se não existir (Cache Miss): busca o produto na coleção 'produtos' do MongoDB.
    4. Se o produto for localizado no MongoDB:
       - Converte o documento para um formato serializável (ex: '_id' em string);
       - Grava a string JSON no Redis na chave 'produto:{sku}' com o TTL informado (via r.set com ex=ttl);
       - Adiciona o campo '_origem': 'MONGODB_RELOAD' e retorna o dicionário.
    5. Se o produto não existir no MongoDB nem no Redis, retorna None.
    """
    # TODO: Implemente a lógica do Desafio 1 aqui
    pass


# ==============================================================================
# DESAFIO 2 (Valor: 2,0 Pontos) -- Histórico de Itens Recentes com Listas Redis
# ==============================================================================
def registrar_historico_navegacao(r: redis.Redis, cliente_id: str, sku: str, max_itens: int = 5) -> list:
    """
    Especificação do Requisito:
    1. Utiliza uma Lista no Redis associada à chave 'historico:{cliente_id}'.
    2. Para evitar duplicatas consecutivas, remove previamente qualquer ocorrência
       do 'sku' na lista utilizando LREM.
    3. Insere o 'sku' no início da lista (cabeça) via LPUSH.
    4. Limita o tamanho máximo da lista aos 'max_itens' mais recentes via LTRIM.
    5. Define uma expiração de 900 segundos (15 minutos) na chave via EXPIRE.
    6. Retorna a lista atual de SKUs navegados pelo cliente (usando LRANGE 0 -1).
    """
    # TODO: Implemente a lógica do Desafio 2 aqui
    pass


# ==============================================================================
# DESAFIO 3 (Valor: 2,0 Pontos) -- Atualizações Atômicas de Arrays no MongoDB
# ==============================================================================
def adicionar_avaliacao_produto(db, sku: str, cliente_id: str, nota: int, comentario: str) -> bool:
    """
    Especificação do Requisito:
    1. Cria um subdocumento de avaliação contendo:
       - 'cliente_id': cliente_id
       - 'nota': nota (inteiro de 1 a 5)
       - 'comentario': comentario
       - 'data': datetime.now(timezone.utc)
    2. Utiliza comandos atômicos do MongoDB para:
       - Adicionar a nova avaliação ao array 'avaliacoes' via $push;
       - Incrementar o campo 'total_avaliacoes' em 1 via $inc.
    3. Recupera o documento atualizado para recalcular a nova 'media_avaliacoes'
       (média aritmética de todas as notas do array 'avaliacoes') e persiste
       o valor arredondado em 2 casas decimais com $set.
    4. Retorna True se o produto foi localizado e atualizado com sucesso;
       retorna False caso o SKU não exista.
    """
    # TODO: Implemente a lógica do Desafio 3 aqui
    pass


# ==============================================================================
# DESAFIO 4 (Valor: 2,0 Pontos) -- Indexação Otimizada pela Regra ESR
# ==============================================================================
def criar_indice_pedidos_esr(db) -> str:
    """
    Especificação do Requisito:
    A equipe de produto identificou uma lentidão crítica na listagem do painel:
    db.pedidos.find({"status": "ENTREGUE", "valor_total": {"$gte": 100.0}}).sort({"data_pedido": -1})
    
    Crie na coleção 'pedidos' o índice composto ótimo seguindo a Regra de Ouro ESR:
    - E (Equality): campo 'status' (ordem ascendente: 1)
    - S (Sort): campo 'data_pedido' (ordem descendente: -1)
    - R (Range): campo 'valor_total' (ordem ascendente: 1)
    
    O índice deve obrigatoriamente ser nomeado como:
    'idx_pedidos_esr_status_data_valor'
    
    Retorne o nome do índice criado.
    """
    # TODO: Implemente a lógica do Desafio 4 aqui
    pass


# ==============================================================================
# DESAFIO 5 (Valor: 2,0 Pontos) -- Pipeline de Agregação de Vendas
# ==============================================================================
def relatorio_vendas_por_categoria(db) -> list:
    """
    Especificação do Requisito:
    Construa e execute um pipeline de agregação no MongoDB sobre a coleção 'pedidos' que:
    1. Estágio 1 ($match): Filtra apenas pedidos cujo 'status' seja estritamente 'ENTREGUE'.
    2. Estágio 2 ($unwind): Desconstrói o array de subdocumentos 'itens'.
    3. Estágio 3 ($group): Agrupa os itens pela categoria ('$itens.categoria'), calculando:
       - 'faturamento_total': somatório de '$itens.subtotal'
       - 'quantidade_total': somatório de '$itens.quantidade'
       - 'ticket_medio_item': média aritmética de '$itens.preco_unitario'
    4. Estágio 4 ($project): Formata os campos de saída:
       - '_id': 0 (oculta o _id padrão)
       - 'categoria': '$_id'
       - 'faturamento_total': arredondado para 2 casas decimais via $round
       - 'quantidade_total': 1
       - 'ticket_medio_item': arredondado para 2 casas decimais via $round
    5. Estágio 5 ($sort): Ordena o resultado pelo 'faturamento_total' de forma decrescente (-1).
    
    Retorna a lista de documentos resultante do pipeline.
    """
    # TODO: Implemente a lógica do Desafio 5 aqui
    pass


# ==============================================================================
# SUÍTE DE TESTES AUTOMATIZADOS (Validação em Laboratório)
# ==============================================================================
def executar_testes():
    print("=" * 75)
    print("IFCE CAMPUS TAUÁ -- BANCO DE DADOS NÃO-RELACIONAIS")
    print("SUÍTE DE AVALIAÇÃO AUTOMATIZADA: AVP1 (LABORATÓRIO N1)")
    print("=" * 75)
    
    try:
        r, db = get_conexoes()
        r.ping()
        db.command("ping")
    except Exception as e:
        print(f"❌ Falha de Conexão com os Bancos: {e}")
        print("Certifique-se de subir o docker compose e executar o povoamento prévio.")
        return

    pontuacao_total = 0.0
    resultados = []

    # Teste 1: Cache-Aside
    print("\n[Executando Teste 1] Padrão Cache-Aside no Redis...")
    try:
        r.delete("produto:SKU-1001")
        # 1ª busca: deve ser Cache Miss
        p1 = buscar_produto_com_cache(r, db, "SKU-1001", ttl_segundos=60)
        assert p1 is not None, "Produto SKU-1001 deveria existir no MongoDB."
        assert p1.get("_origem") == "MONGODB_RELOAD", "Primeira busca deveria ter origem MONGODB_RELOAD."
        assert r.exists("produto:SKU-1001"), "Chave deveria ter sido gravada no Redis."
        ttl = r.ttl("produto:SKU-1001")
        assert 0 < ttl <= 60, f"TTL inválido: {ttl}."

        # 2ª busca: deve ser Cache Hit
        p2 = buscar_produto_com_cache(r, db, "SKU-1001", ttl_segundos=60)
        assert p2.get("_origem") == "REDIS_CACHE", "Segunda busca deveria ter origem REDIS_CACHE."
        
        # Busca inexistente
        p_inexistente = buscar_produto_com_cache(r, db, "SKU-INEXISTENTE-9999")
        assert p_inexistente is None, "Produto inexistente deveria retornar None."

        print("✔ Desafio 1 APROVADO (+2,0 Pontos)")
        pontuacao_total += 2.0
        resultados.append(("Desafio 1 (Cache-Aside Redis)", "APROVADO", 2.0))
    except Exception as e:
        print(f"❌ Desafio 1 FALHOU: {e}")
        resultados.append(("Desafio 1 (Cache-Aside Redis)", f"FALHOU ({e})", 0.0))

    # Teste 2: Histórico de Navegação
    print("\n[Executando Teste 2] Histórico de Navegação com Listas no Redis...")
    try:
        cid = "CLI-TESTE-999"
        r.delete(f"historico:{cid}")
        
        registrar_historico_navegacao(r, cid, "SKU-1001", max_itens=3)
        registrar_historico_navegacao(r, cid, "SKU-1002", max_itens=3)
        registrar_historico_navegacao(r, cid, "SKU-1003", max_itens=3)
        
        # Inserção duplicada de SKU-1001: deve subir para a cabeça sem duplicar
        h1 = registrar_historico_navegacao(r, cid, "SKU-1001", max_itens=3)
        assert h1 == ["SKU-1001", "SKU-1003", "SKU-1002"], f"Ordem incorreta após re-visita: {h1}"
        
        # Inserção que excede max_itens=3
        h2 = registrar_historico_navegacao(r, cid, "SKU-1004", max_itens=3)
        assert len(h2) == 3, f"Lista deveria ter no máximo 3 itens, obtido {len(h2)}"
        assert h2 == ["SKU-1004", "SKU-1001", "SKU-1003"], f"Ordem incorreta após LTRIM: {h2}"
        
        ttl_hist = r.ttl(f"historico:{cid}")
        assert 0 < ttl_hist <= 900, "TTL do histórico não foi configurado corretamente."

        print("✔ Desafio 2 APROVADO (+2,0 Pontos)")
        pontuacao_total += 2.0
        resultados.append(("Desafio 2 (Histórico Listas Redis)", "APROVADO", 2.0))
    except Exception as e:
        print(f"❌ Desafio 2 FALHOU: {e}")
        resultados.append(("Desafio 2 (Histórico Listas Redis)", f"FALHOU ({e})", 0.0))

    # Teste 3: Atualizações Atômicas no MongoDB
    print("\n[Executando Teste 3] Atualizações Atômicas de Arrays no MongoDB...")
    try:
        sku_alvo = "SKU-1002"
        doc_antes = db.produtos.find_one({"sku": sku_alvo})
        tot_antes = doc_antes.get("total_avaliacoes", 0)
        
        ok = adicionar_avaliacao_produto(db, sku_alvo, "CLI-200", 4, "Muito bom produto!")
        assert ok is True, "Função deveria retornar True para produto existente."
        
        doc_depois = db.produtos.find_one({"sku": sku_alvo})
        assert doc_depois["total_avaliacoes"] == tot_antes + 1, "total_avaliacoes não foi incrementado."
        assert len(doc_depois["avaliacoes"]) == tot_antes + 1, "Array avaliacoes não recebeu novo subdocumento."
        
        notas = [av["nota"] for av in doc_depois["avaliacoes"]]
        media_esperada = round(sum(notas) / len(notas), 2)
        assert abs(doc_depois["media_avaliacoes"] - media_esperada) < 0.01, f"Média incorreta: esperada {media_esperada}, obtida {doc_depois['media_avaliacoes']}"
        
        # Teste com SKU inexistente
        assert adicionar_avaliacao_produto(db, "SKU-NAO-EXISTE", "CLI-1", 5, "x") is False

        print("✔ Desafio 3 APROVADO (+2,0 Pontos)")
        pontuacao_total += 2.0
        resultados.append(("Desafio 3 (CRUD Atômico MongoDB)", "APROVADO", 2.0))
    except Exception as e:
        print(f"❌ Desafio 3 FALHOU: {e}")
        resultados.append(("Desafio 3 (CRUD Atômico MongoDB)", f"FALHOU ({e})", 0.0))

    # Teste 4: Regra ESR
    print("\n[Executando Teste 4] Criação e Validação de Índice Composto ESR...")
    try:
        nome_idx = criar_indice_pedidos_esr(db)
        assert nome_idx == "idx_pedidos_esr_status_data_valor", f"Nome do índice incorreto: {nome_idx}"
        
        indices = db.pedidos.index_information()
        assert "idx_pedidos_esr_status_data_valor" in indices, "Índice não encontrado na coleção pedidos."
        
        campos_idx = indices["idx_pedidos_esr_status_data_valor"]["key"]
        esperado = [("status", 1), ("data_pedido", -1), ("valor_total", 1)]
        assert campos_idx == esperado, f"Campos ou ordenação ESR incorretos: {campos_idx}"
        
        # Validação do plano de execução via explain()
        plan = db.pedidos.find(
            {"status": "ENTREGUE", "valor_total": {"$gte": 50.0}}
        ).sort({"data_pedido": -1}).explain()
        
        stages_str = json.dumps(plan)
        assert "IXSCAN" in stages_str, "O plano de execução deveria utilizar IXSCAN."
        assert "idx_pedidos_esr_status_data_valor" in stages_str, "O plano não utilizou o índice ESR criado."

        print("✔ Desafio 4 APROVADO (+2,0 Pontos)")
        pontuacao_total += 2.0
        resultados.append(("Desafio 4 (Índice Composto ESR)", "APROVADO", 2.0))
    except Exception as e:
        print(f"❌ Desafio 4 FALHOU: {e}")
        resultados.append(("Desafio 4 (Índice Composto ESR)", f"FALHOU ({e})", 0.0))

    # Teste 5: Aggregation Pipeline
    print("\n[Executando Teste 5] Pipeline de Agregação de Vendas por Categoria...")
    try:
        rel = relatorio_vendas_por_categoria(db)
        assert isinstance(rel, list), "O relatório de agregação deve retornar uma lista."
        assert len(rel) > 0, "O pipeline retornou uma lista vazia."
        
        primeiro = rel[0]
        chaves_esperadas = {"categoria", "faturamento_total", "quantidade_total", "ticket_medio_item"}
        assert set(primeiro.keys()) == chaves_esperadas, f"Campos incorretos no documento agregado: {primeiro.keys()}"
        
        # Validar ordenação decrescente de faturamento
        faturamentos = [item["faturamento_total"] for item in rel]
        assert faturamentos == sorted(faturamentos, reverse=True), "O resultado não está ordenado por faturamento_total decrescente."

        print("✔ Desafio 5 APROVADO (+2,0 Pontos)")
        pontuacao_total += 2.0
        resultados.append(("Desafio 5 (Pipeline Aggregation)", "APROVADO", 2.0))
    except Exception as e:
        print(f"❌ Desafio 5 FALHOU: {e}")
        resultados.append(("Desafio 5 (Pipeline Aggregation)", f"FALHOU ({e})", 0.0))

    # Relatório Final
    print("\n" + "=" * 75)
    print("QUADRO RESUMO DE PONTUAÇÃO FINAL:")
    print("=" * 75)
    for desc, st, pt in resultados:
        print(f"  * {desc:<38} : {st:<18} [{pt:.1f} / 2.0 pts]")
    print("-" * 75)
    print(f"  NOTA FINAL OBTIDA NA AVP1: {pontuacao_total:.1f} / 10.0 PONTOS")
    print("=" * 75)

if __name__ == "__main__":
    executar_testes()
